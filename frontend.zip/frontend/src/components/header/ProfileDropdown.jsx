import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  UserRound,
  FlaskConical,
  PlusCircle,
  Gift,
  Mail,
  LogOut,
  IndianRupee,
} from "lucide-react";
import Toggle from "../common/Toggle";
export default function ProfileDropdown({ onClose }) {
  const nav = useNavigate(),
    [n, setN] = useState(true);
  const go = (p) => {
    onClose();
    nav(p);
  };
  const logout = () => {
    localStorage.removeItem("token");
    sessionStorage.clear();
    onClose();
    nav("/login", { replace: true });
  };
  return (
    <div>
      <div className="profile-head">
        <strong>DEMO LAB OWNER</strong>
        <b>Account owner</b>
        <small>Lab ID #: DEMO001</small>
      </div>
      <button className="today">
        <IndianRupee /> My today's total : <span>Rs.0</span>⌄
      </button>
      <div className="profile-links">
        <button onClick={() => go("/manage/my-account")}>
          <UserRound />
          My account
        </button>
        <button onClick={() => go("/manage/lab-account")}>
          <FlaskConical />
          Lab account
        </button>
        <button onClick={() => go("/manage/setup-lab")}>
          <PlusCircle />
          Setup a new lab
        </button>
        <button onClick={() => go("/manage/referral-program")}>
          <Gift />
          Referral program
        </button>
        <button onClick={() => go("/manage/email-preferences")}>
          <Mail />
          Email subscription preferences
        </button>
      </div>
      <Toggle label="Enable new navigation" checked={n} onChange={setN} />
      <button className="logout" onClick={logout}>
        <LogOut />
        Logout
      </button>
    </div>
  );
}
