
import { useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Clock3,
  CreditCard,
  FileCheck2,
  FileText,
  FlaskConical,
  Headphones,
  HeartPulse,
  Menu,
  Microscope,
  ShieldCheck,
  Sparkles,
  Stethoscope,
  Users,
  X,
  Activity,
  LayoutDashboard,
  Bell,
  Settings,
  Search,
  CalendarDays,
  ChartNoAxesCombined,
  ClipboardList,
} from "lucide-react";

import "./landing.css";
import labLimsLogo from "../../assets/logo2.png";
/* -------------------------------------------------------
   REUSABLE CUSTOM LOGO
   Place your image at: public/lablims-logo.png
------------------------------------------------------- */

function LabLimsLogo({ className = "lp-brand", onClick }) {
  return (
    <Link
      to="/"
      className={className}
      onClick={onClick}
      aria-label="LabLIMS home"
    >
      <img
        src={labLimsLogo}
        alt="LabLIMS"
        className="lp-custom-logo"
      />
    </Link>
  );
}

/* -------------------------------------------------------
   NAVBAR
------------------------------------------------------- */

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  const navLinks = [
    { label: "Features", href: "#features" },
    { label: "Solutions", href: "#solutions" },
    { label: "Why LabLIMS", href: "#why-lablims" },
    { label: "Contact", href: "#contact" },
  ];

  return (
    <header className="lp-header">
      <nav className="lp-navbar">
        <LabLimsLogo onClick={closeMenu} />

        <div className={`lp-nav-links ${menuOpen ? "active" : ""}`}>
          {navLinks.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="lp-nav-link"
              onClick={closeMenu}
            >
              {item.label}
            </a>
          ))}

          <div className="lp-mobile-actions">
            <Link
              to="/login"
              className="lp-login-link"
              onClick={closeMenu}
            >
              Log in
            </Link>

            <Link
              to="/signup"
              className="lp-btn lp-btn-primary"
              onClick={closeMenu}
            >
              Get started <ArrowRight size={16} />
            </Link>
          </div>
        </div>

        <div className="lp-nav-actions">
          <Link to="/login" className="lp-login-link">
            Log in
          </Link>

          <Link to="/signup" className="lp-btn lp-btn-primary lp-nav-cta">
            Get started <ArrowRight size={16} />
          </Link>
        </div>

        <button
          type="button"
          className="lp-menu-toggle"
          aria-label={menuOpen ? "Close navigation" : "Open navigation"}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? <X size={23} /> : <Menu size={23} />}
        </button>
      </nav>
    </header>
  );
}

/* -------------------------------------------------------
   DASHBOARD PREVIEW
------------------------------------------------------- */

function DashboardPreview() {
  const [activeTab, setActiveTab] = useState("Overview");

  const tabs = [
    { label: "Overview", icon: LayoutDashboard },
    { label: "Patients", icon: Users },
    { label: "Investigations", icon: Microscope },
    { label: "Reports", icon: FileText },
  ];

  const stats = [
    {
      label: "Total Patients",
      value: "1,284",
      change: "+12.8%",
      icon: Users,
      color: "blue",
    },
    {
      label: "Tests Completed",
      value: "846",
      change: "+8.2%",
      icon: FlaskConical,
      color: "purple",
    },
    {
      label: "Reports Ready",
      value: "92",
      change: "+5.4%",
      icon: FileCheck2,
      color: "green",
    },
  ];

  const patients = [
    {
      id: "PT-1024",
      name: "Aarav Sharma",
      test: "Complete Blood Count",
      status: "Completed",
      color: "green",
    },
    {
      id: "PT-1025",
      name: "Ananya Verma",
      test: "Liver Function Test",
      status: "Processing",
      color: "orange",
    },
    {
      id: "PT-1026",
      name: "Rohan Gupta",
      test: "Thyroid Profile",
      status: "Completed",
      color: "green",
    },
    {
      id: "PT-1027",
      name: "Priya Singh",
      test: "Blood Glucose",
      status: "Pending",
      color: "blue",
    },
  ];

  return (
    <div className="lp-dashboard">
      <aside className="lp-dash-sidebar">
        <LabLimsLogo className="lp-dash-brand" />

        <div className="lp-dash-workspace">
          <div className="lp-workspace-icon">
            <HeartPulse size={17} />
          </div>
          <div>
            <strong>City Diagnostics</strong>
            <span>Laboratory workspace</span>
          </div>
          <ChevronDown size={15} />
        </div>

        <div className="lp-dash-menu-label">WORKSPACE</div>

        <div className="lp-dash-menu">
          {tabs.map(({ label, icon: Icon }) => (
            <button
              type="button"
              key={label}
              className={`lp-dash-menu-item ${
                activeTab === label ? "active" : ""
              }`}
              onClick={() => setActiveTab(label)}
            >
              <Icon size={17} />
              <span>{label}</span>
              {label === "Investigations" && (
                <span className="lp-menu-count">8</span>
              )}
            </button>
          ))}
        </div>

        <div className="lp-dash-menu-label lp-dash-tools-label">
          MANAGEMENT
        </div>

        <div className="lp-dash-menu">
          <button type="button" className="lp-dash-menu-item">
            <CalendarDays size={17} />
            <span>Appointments</span>
          </button>

          <button type="button" className="lp-dash-menu-item">
            <CreditCard size={17} />
            <span>Billing</span>
          </button>

          <button type="button" className="lp-dash-menu-item">
            <ChartNoAxesCombined size={17} />
            <span>Analytics</span>
          </button>

          <button type="button" className="lp-dash-menu-item">
            <Settings size={17} />
            <span>Settings</span>
          </button>
        </div>

        <div className="lp-dash-sidebar-bottom">
          <div className="lp-dash-support-icon">
            <CircleHelp size={17} />
          </div>
          <div>
            <strong>Need assistance?</strong>
            <span>Visit help center</span>
          </div>
          <ArrowUpRight size={15} />
        </div>
      </aside>

      <section className="lp-dash-main">
        <div className="lp-dash-topbar">
          <div className="lp-dash-breadcrumb">
            Workspace <ChevronRight size={14} />{" "}
            <strong>{activeTab}</strong>
          </div>

          <div className="lp-dash-top-actions">
            <div className="lp-dash-search">
              <Search size={15} />
              <span>Search anything...</span>
              <kbd>⌘ K</kbd>
            </div>

            <button
              type="button"
              className="lp-dash-icon-button"
              aria-label="Notifications"
            >
              <Bell size={17} />
              <span className="lp-notification-dot" />
            </button>

            <div className="lp-dash-avatar">AK</div>
          </div>
        </div>

        <div className="lp-dash-content">
          <div className="lp-dash-welcome">
            <div>
              <div className="lp-dash-date">
                <Clock3 size={13} /> MONDAY, OCTOBER 26
              </div>
              <h3>Good morning, Admin 👋</h3>
              <p>Here&apos;s what&apos;s happening in your laboratory today.</p>
            </div>

            <button type="button" className="lp-dash-date-button">
              <CalendarDays size={15} />
              Today
              <ChevronDown size={14} />
            </button>
          </div>

          <div className="lp-dash-stats">
            {stats.map(({ label, value, change, icon: Icon, color }) => (
              <div className="lp-dash-stat-card" key={label}>
                <div className="lp-dash-stat-top">
                  <span>{label}</span>
                  <div className={`lp-dash-stat-icon ${color}`}>
                    <Icon size={17} />
                  </div>
                </div>
                <div className="lp-dash-stat-bottom">
                  <strong>{value}</strong>
                  <span className="lp-dash-stat-change">
                    <ArrowUpRight size={13} /> {change}
                  </span>
                </div>
                <div className="lp-dash-stat-caption">
                  compared to last month
                </div>
              </div>
            ))}
          </div>

          <div className="lp-dash-section-heading">
            <div>
              <h4>Recent patients</h4>
              <p>Track patient activity and investigation status.</p>
            </div>
            <button type="button" className="lp-dash-view-all">
              View all <ArrowRight size={14} />
            </button>
          </div>

          <div className="lp-dash-table-wrap">
            <table className="lp-dash-table">
              <thead>
                <tr>
                  <th>Patient</th>
                  <th>Patient ID</th>
                  <th>Investigation</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {patients.map((patient, index) => (
                  <tr key={patient.id}>
                    <td>
                      <div className="lp-patient-name">
                        <div className={`lp-patient-avatar avatar-${index + 1}`}>
                          {patient.name
                            .split(" ")
                            .map((part) => part[0])
                            .join("")}
                        </div>
                        <strong>{patient.name}</strong>
                      </div>
                    </td>
                    <td>
                      <span className="lp-patient-id">{patient.id}</span>
                    </td>
                    <td>{patient.test}</td>
                    <td>
                      <span
                        className={`lp-status-badge ${patient.color}`}
                      >
                        <span className="lp-status-dot" />
                        {patient.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="lp-dash-bottom-cards">
            <div className="lp-dash-mini-card">
              <div className="lp-dash-mini-icon purple">
                <ClipboardList size={17} />
              </div>
              <div>
                <span>Pending investigations</span>
                <strong>24</strong>
              </div>
              <span className="lp-mini-trend">Needs attention</span>
            </div>

            <div className="lp-dash-mini-card">
              <div className="lp-dash-mini-icon green">
                <ShieldCheck size={17} />
              </div>
              <div>
                <span>Quality checks</span>
                <strong>98.6%</strong>
              </div>
              <span className="lp-mini-trend positive">
                <Check size={12} /> On track
              </span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

/* -------------------------------------------------------
   HERO SECTION
------------------------------------------------------- */

function HeroSection() {
  return (
    <section className="lp-hero">
      <div className="lp-hero-glow lp-hero-glow-one" />
      <div className="lp-hero-glow lp-hero-glow-two" />

      <div className="lp-container lp-hero-grid">
        <div className="lp-hero-copy">
          <div className="lp-eyebrow">
            <span className="lp-eyebrow-icon">
              <Sparkles size={14} />
            </span>
            SMARTER LABORATORY MANAGEMENT
            <span className="lp-eyebrow-dot" />
          </div>

          <h1>
            Your laboratory.
            <br />
            <span>One intelligent</span>
            <br />
            system.
          </h1>

          <p className="lp-hero-description">
            Simplify laboratory operations, manage patient records, track
            investigations, and deliver reports — all from one connected
            platform built for modern diagnostic laboratories.
          </p>

          <div className="lp-hero-actions">
            <Link to="/register" className="lp-btn lp-btn-primary lp-btn-large">
              Get started free <ArrowRight size={17} />
            </Link>
            <a href="#features" className="lp-btn lp-btn-secondary lp-btn-large">
              Explore features <ChevronRight size={17} />
            </a>
          </div>

          <div className="lp-hero-trust">
            <div className="lp-trust-icon">
              <ShieldCheck size={17} />
            </div>
            <div>
              <strong>Built for laboratory workflows</strong>
              <span>Designed to bring your daily operations together.</span>
            </div>
          </div>

          <div className="lp-hero-metrics">
            <div>
              <strong>One</strong>
              <span>connected workspace</span>
            </div>
            <div className="lp-metric-divider" />
            <div>
              <strong>Real-time</strong>
              <span>workflow visibility</span>
            </div>
            <div className="lp-metric-divider" />
            <div>
              <strong>Less manual</strong>
              <span>administrative work</span>
            </div>
          </div>
        </div>

        <div className="lp-hero-visual">
          <div className="lp-visual-orbit lp-orbit-one" />
          <div className="lp-visual-orbit lp-orbit-two" />

          <div className="lp-visual-floating-card lp-float-card-top">
            <div className="lp-floating-icon green">
              <Check size={16} />
            </div>
            <div>
              <strong>Report generated</strong>
              <span>Ready for review</span>
            </div>
          </div>

          <DashboardPreview />

          <div className="lp-visual-floating-card lp-float-card-bottom">
            <div className="lp-floating-icon blue">
              <Activity size={16} />
            </div>
            <div>
              <strong>Workflow overview</strong>
              <span>Stay on top of daily activity</span>
            </div>
          </div>
        </div>
      </div>

      <div className="lp-hero-bottom-fade" />
    </section>
  );
}

/* -------------------------------------------------------
   TRUST STRIP
------------------------------------------------------- */

function TrustStrip() {
  const items = [
    { icon: FlaskConical, label: "Laboratory workflows" },
    { icon: Users, label: "Patient management" },
    { icon: FileCheck2, label: "Digital reporting" },
    { icon: ShieldCheck, label: "Structured operations" },
    { icon: HeartPulse, label: "Healthcare focused" },
  ];

  return (
    <section className="lp-trust-strip">
      <div className="lp-container">
        <p>ONE PLATFORM FOR YOUR LABORATORY&apos;S ESSENTIAL WORKFLOWS</p>
        <div className="lp-trust-items">
          {items.map(({ icon: Icon, label }) => (
            <div className="lp-trust-item" key={label}>
              <Icon size={19} />
              <span>{label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------
   FEATURES
------------------------------------------------------- */

function FeaturesSection() {
  const features = [
    {
      icon: Users,
      color: "blue",
      number: "01",
      title: "Patient management",
      description:
        "Keep patient information organized and accessible with a streamlined registration and record-management workflow.",
      points: ["Patient registration", "Searchable records", "Patient history"],
    },
    {
      icon: Microscope,
      color: "purple",
      number: "02",
      title: "Investigation management",
      description:
        "Organize laboratory investigations, manage test requests, and monitor progress from one central workspace.",
      points: ["Test organization", "Status tracking", "Workflow visibility"],
    },
    {
      icon: FileText,
      color: "green",
      number: "03",
      title: "Reports and results",
      description:
        "Prepare clear laboratory reports and keep reporting activity connected to patient and investigation records.",
      points: ["Report preparation", "Result tracking", "Digital workflow"],
    },
    {
      icon: CreditCard,
      color: "orange",
      number: "04",
      title: "Billing and payments",
      description:
        "Keep billing information organized alongside laboratory operations for a smoother administrative process.",
      points: ["Billing records", "Invoice tracking", "Payment visibility"],
    },
    {
      icon: ChartNoAxesCombined,
      color: "cyan",
      number: "05",
      title: "Insights and analytics",
      description:
        "Get a clearer overview of laboratory activity with organized operational data and performance summaries.",
      points: ["Activity summaries", "Operational trends", "Quick overview"],
    },
    {
      icon: ShieldCheck,
      color: "pink",
      number: "06",
      title: "Controlled access",
      description:
        "Support organized team workflows with access patterns designed around laboratory responsibilities.",
      points: ["Team workflows", "Role-aware operations", "Organized access"],
    },
  ];

  return (
    <section className="lp-section lp-features-section" id="features">
      <div className="lp-container">
        <div className="lp-section-heading">
          <div className="lp-section-eyebrow">
            <span /> WHAT YOU CAN DO
          </div>
          <h2>
            Everything your lab needs.
            <br />
            <span>Nothing it doesn&apos;t.</span>
          </h2>
          <p>
            Bring essential laboratory workflows together with a platform
            designed to make everyday work more organized and manageable.
          </p>
        </div>

        <div className="lp-features-grid">
          {features.map(
            ({ icon: Icon, color, number, title, description, points }) => (
              <article className="lp-feature-card" key={number}>
                <div className="lp-feature-card-top">
                  <div className={`lp-feature-icon ${color}`}>
                    <Icon size={22} />
                  </div>
                  <span className="lp-feature-number">{number}</span>
                </div>

                <h3>{title}</h3>
                <p>{description}</p>

                <ul className="lp-feature-points">
                  {points.map((point) => (
                    <li key={point}>
                      <Check size={14} />
                      {point}
                    </li>
                  ))}
                </ul>

                <div className="lp-feature-bottom-line" />
              </article>
            )
          )}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------
   SOLUTIONS
------------------------------------------------------- */

function SolutionsSection() {
  const solutions = [
    {
      icon: Stethoscope,
      title: "Diagnostic laboratories",
      text: "Coordinate patient records, investigations, reporting, and day-to-day laboratory administration.",
    },
    {
      icon: FlaskConical,
      title: "Laboratory teams",
      text: "Keep essential tasks and investigation statuses visible so team members can follow the workflow.",
    },
    {
      icon: HeartPulse,
      title: "Healthcare operations",
      text: "Connect administrative and diagnostic workflows in a shared, organized workspace.",
    },
  ];

  return (
    <section className="lp-section lp-solutions-section" id="solutions">
      <div className="lp-container lp-solutions-grid">
        <div className="lp-solutions-copy">
          <div className="lp-section-eyebrow">
            <span /> MADE FOR YOUR WORKFLOW
          </div>

          <h2>
            Built around the way
            <br />
            <span>laboratories work.</span>
          </h2>

          <p>
            LabLIMS brings key operational tasks into one place, helping your
            team spend less time navigating disconnected processes.
          </p>

          <Link to="/register" className="lp-text-link">
            Discover LabLIMS <ArrowRight size={16} />
          </Link>
        </div>

        <div className="lp-solutions-list">
          {solutions.map(({ icon: Icon, title, text }, index) => (
            <article className="lp-solution-item" key={title}>
              <div className={`lp-solution-icon solution-${index + 1}`}>
                <Icon size={22} />
              </div>
              <div className="lp-solution-content">
                <h3>{title}</h3>
                <p>{text}</p>
              </div>
              <ChevronRight size={18} className="lp-solution-arrow" />
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------
   WHY LABLIMS
------------------------------------------------------- */

function WhyLabLimsSection() {
  const benefits = [
    {
      icon: Activity,
      title: "A clearer overview",
      text: "See key laboratory activity in one workspace instead of switching between disconnected screens.",
    },
    {
      icon: Clock3,
      title: "Streamlined daily work",
      text: "Bring recurring administrative and diagnostic tasks into a more consistent workflow.",
    },
    {
      icon: FileCheck2,
      title: "Connected information",
      text: "Keep patient, investigation, and reporting workflows linked for easier follow-through.",
    },
    {
      icon: Users,
      title: "Team-friendly workflows",
      text: "Give laboratory staff a common place to follow progress and coordinate daily operations.",
    },
  ];

  return (
    <section
      className="lp-section lp-why-section"
      id="why-lablims"
    >
      <div className="lp-container">
        <div className="lp-section-heading">
          <div className="lp-section-eyebrow">
            <span /> THE LABLIMS DIFFERENCE
          </div>
          <h2>
            Less complexity.
            <br />
            <span>More clarity.</span>
          </h2>
          <p>
            A practical approach to managing the everyday details that keep a
            laboratory running.
          </p>
        </div>

        <div className="lp-benefits-grid">
          {benefits.map(({ icon: Icon, title, text }, index) => (
            <article className="lp-benefit-card" key={title}>
              <div className={`lp-benefit-icon benefit-${index + 1}`}>
                <Icon size={22} />
              </div>
              <h3>{title}</h3>
              <p>{text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------
   CTA
------------------------------------------------------- */

function CTASection() {
  return (
    <section className="lp-cta-section" id="contact">
      <div className="lp-container">
        <div className="lp-cta-card">
          <div className="lp-cta-glow lp-cta-glow-one" />
          <div className="lp-cta-glow lp-cta-glow-two" />

          <div className="lp-cta-content">
            <div className="lp-cta-eyebrow">
              <Sparkles size={14} /> GET STARTED WITH LABLIMS
            </div>

            <h2>
              Ready to bring your
              <br />
              laboratory together?
            </h2>

            <p>
              Take the next step toward a more organized laboratory workflow
              with LabLIMS.
            </p>

            <div className="lp-cta-actions">
              <Link
                to="/register"
                className="lp-btn lp-btn-light lp-btn-large"
              >
                Get started <ArrowRight size={17} />
              </Link>

              <a href="mailto:support@labl​ims.com" className="lp-cta-contact">
                <Headphones size={16} /> Contact support
              </a>
            </div>
          </div>

          <div className="lp-cta-decoration" aria-hidden="true">
            <div className="lp-cta-decoration-ring ring-one" />
            <div className="lp-cta-decoration-ring ring-two" />
            <div className="lp-cta-decoration-ring ring-three" />
            <div className="lp-cta-decoration-center">
              <FlaskConical size={42} />
            </div>
            <div className="lp-cta-decoration-dot dot-one" />
            <div className="lp-cta-decoration-dot dot-two" />
            <div className="lp-cta-decoration-dot dot-three" />
          </div>
        </div>
      </div>
    </section>
  );
}

/* -------------------------------------------------------
   FOOTER
------------------------------------------------------- */

function Footer() {
  const productLinks = [
    { label: "Features", href: "#features" },
    { label: "Solutions", href: "#solutions" },
    { label: "Why LabLIMS", href: "#why-lablims" },
  ];

  const resourceLinks = [
    { label: "Help center", href: "/help-center" },
    { label: "Contact support", href: "/contact-support" },
  ];

  const legalLinks = [
    { label: "Privacy policy", href: "/privacy-policy" },
    { label: "Terms of service", href: "/terms" },
  ];

  const renderLinks = (links) =>
    links.map((item) =>
      item.href.startsWith("#") ? (
        <a href={item.href} key={item.label}>
          {item.label}
        </a>
      ) : (
        <Link to={item.href} key={item.label}>
          {item.label}
        </Link>
      )
    );

  return (
    <footer className="lp-footer">
      <div className="lp-container">
        <div className="lp-footer-main">
          <div className="lp-footer-brand-column">
            <LabLimsLogo />

            <p>
              A connected workspace for modern laboratory operations.
              Organize patient records, investigations, and reporting with
              LabLIMS.
            </p>

            <div className="lp-footer-badge">
              <span className="lp-footer-badge-dot" />
              Designed for laboratory workflows
            </div>
          </div>

          <div className="lp-footer-links-column">
            <h4>Product</h4>
            {renderLinks(productLinks)}
          </div>

          <div className="lp-footer-links-column">
            <h4>Resources</h4>
            {renderLinks(resourceLinks)}
          </div>

          <div className="lp-footer-links-column">
            <h4>Legal</h4>
            {renderLinks(legalLinks)}
          </div>
        </div>

        <div className="lp-footer-bottom">
          <span>
            © {new Date().getFullYear()} LabLIMS. All rights reserved.
          </span>

          <a href="#top" className="lp-back-to-top">
            Back to top <ArrowUpRight size={14} />
          </a>
        </div>
      </div>
    </footer>
  );
}

/* -------------------------------------------------------
   MAIN LANDING PAGE
------------------------------------------------------- */

export default function Landing() {
  return (
    <main className="lab-landing" id="top">
      <Navbar />
      <HeroSection />
      <TrustStrip />
      <FeaturesSection />
      <SolutionsSection />
      <WhyLabLimsSection />
      <CTASection />
      <Footer />
    </main>
  );
}
