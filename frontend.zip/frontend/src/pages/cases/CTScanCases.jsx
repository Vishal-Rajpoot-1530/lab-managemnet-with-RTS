import DataTable from "../../components/common/DataTable";
import { ctCases } from "./mockData";
import "./cases.css";
export default function CTScanCases() {
  const cols = [
    { key: "regNo", label: "Reg no." },
    { key: "date", label: "Date" },
    { key: "patient", label: "Patient" },
    { key: "investigations", label: "Investigations" },
    {
      key: "status",
      label: "Status",
      render: (v) => <span className="case-status soft">{v}</span>,
    },
  ];
  return (
    <div className="cases-page">
      <h1>Ct scan cases</h1>
      <div className="case-field" style={{ width: 235, marginBottom: 10 }}>
        <input value="23/08/2026 - 21/09/2026" readOnly />
      </div>
      <DataTable columns={cols} rows={ctCases} />
    </div>
  );
}
