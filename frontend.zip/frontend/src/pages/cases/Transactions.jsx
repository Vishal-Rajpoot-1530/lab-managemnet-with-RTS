import DataTable from "../../components/common/DataTable";
import { billingApiService } from "../../api";
import useApiList from "../../api/core/useApiList";
import "./cases.css";
const load = (q) => billingApiService.transactions(q);
export default function Transactions() {
  const { rows, loading, error, reload } = useApiList(load);
  const cols = [
    { key: "id", label: "ID" },
    { key: "registrationNo", label: "REG. NO." },
    { key: "patientName", label: "PATIENT NAME" },
    { key: "referrerName", label: "REFERRED BY" },
    { key: "date", label: "DATE" },
    { key: "time", label: "TIME" },
    { key: "amount", label: "AMOUNT" },
    { key: "paymentMode", label: "METHOD" },
    { key: "receivedBy", label: "RECEIVED BY" },
  ];
  return (
    <div className="cases-page">
      <h1>Transactions</h1>
      <button className="case-btn primary" onClick={() => reload({})}>
        Refresh
      </button>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p className="api-error">{error}</p>
      ) : (
        <DataTable columns={cols} rows={rows} />
      )}
    </div>
  );
}
