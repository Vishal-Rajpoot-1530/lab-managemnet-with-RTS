import DataTable from "../../components/common/DataTable";
import { agentApiService } from "../../api";
import useApiList from "../../api/core/useApiList";
import "./cases.css";
const load = (q) => agentApiService.list(q);
export default function Agents() {
  const { rows, loading, error } = useApiList(load);
  const cols = [
    { key: "id", label: "AGENT ID" },
    { key: "name", label: "NAME" },
    { key: "createdAt", label: "REGISTERED ON" },
    { key: "status", label: "STATUS" },
  ];
  return (
    <div className="cases-page">
      <h1>Sample collection agents</h1>
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p className="api-error">{error}</p>
      ) : (
        <DataTable columns={cols} rows={rows} />
      )}
    </div>
  );
}
